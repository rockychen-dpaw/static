print "Importing mybottle.__init__"
import bottle
