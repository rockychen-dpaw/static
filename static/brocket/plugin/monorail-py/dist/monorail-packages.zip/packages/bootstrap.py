
import json
import os
import os.path as osp
from distutils.version import LooseVersion
import shutil
import urllib
import zipfile


API_URL = "http://static.dpaw.wa.gov.au/static/brocket/plugin/monorail-py/latest.json"

def update_api(other):
    from .. import packages
    if API_URL:
        latest = json.load(urllib.urlopen(API_URL))
        print(latest)
        root_fp = osp.dirname(osp.dirname(__file__))
        zip_fp = os.path.join(root_fp, latest['name'])
        unzip_fp = os.path.join(root_fp, 'packages')
        if LooseVersion(packages.__version__) < LooseVersion(latest['version']):
            print("Updating from {}".format(latest['url']))
            urllib.urlretrieve(latest['url'], zip_fp)
            with zipfile.ZipFile(zip_fp, "r") as src:
                print('Clearing packages')
                shutil.rmtree(unzip_fp)
                print('Extracting')
                src.extractall(root_fp)
        else:
            print("Skipping update")
    if hasattr(other, "API"):
        from .. import packages
        reload(packages)
        from packages.api import monorail_api
        reload(monorail_api)
    else:
        from .api import monorail_api
    other.API = monorail_api.API(other.iface)
    return "Updated monorail_api.py module from {}".format(API_URL)
