
import json
import os
import os.path as osp
from distutils.version import LooseVersion
import shutil
import tempfile
import urllib
import zipfile


API_URL = "http://static.dpaw.wa.gov.au/static/brocket/plugin/monorail-py/latest.json"
PKG_FOLDER = 'packages'

def update_api(other):
    from .. import packages
    if API_URL:
        spec = latest_version(API_URL)
        if is_latest(packages.__version__, spec['version']):
            print("Skipping update")
        else:
            remove_old_packages()    # Will default to packages dir
            zip_fp = get_pkg_zip(spec['url'])
            extract_zip(zip_fp, cleanup=True)
    if hasattr(other, "API"):
        from .. import packages
        reload(packages)
        from packages.api import monorail_api
        reload(monorail_api)
    else:
        from .api import monorail_api
    other.API = monorail_api.API(other.iface)
    return "Updated monorail_api.py module from {}".format(API_URL)

### Helper functions #########################################

def extract_zip(src, destdir, cleanup=False):
    with zipfile.ZipFile(src, "r") as src:
        src.extractall(destdir)
    if cleanup:
        os.remove(src)

def get_pkg_zip(url, tmp_fp=None):
    if tmp_fp is None:
        f = tempfile.NamedTemporaryFile(delete=False)
        tmp_fp = f.name
    urllib.urlretrieve(url, tmp_fp)
    return tmp_fp

def is_latest(current, desired):
    return LooseVersion(current) >= LooseVersion(desired)

def latest_version(url):
    return json.load(urllib.urlopen(API_URL))

def remove_old_packages(pkg_dir=None):
    if pkg_dir is None:
        pkg_dir = osp.join(second_parent(__file__), PKG_FOLDER)
    if osp.isdir(pkg_dir):
        shutil.rmtree(pkg_dir)
    else:
        raise IOError('Directory {} does not exist'.format(pkg_dir))

def second_parent(fp):
    return osp.dirname(osp.dirname(fp))

def unzip_filepath():
    root_fp = osp.dirname(osp.dirname(__file__))
    unzip_fp = os.path.join(root_fp, PKG_FOLDER)
    return root_fp, unzip_fp
