import csv
import json
import os.path as osp
from StringIO import StringIO

from qgis.core import *

__version__ = "0.2.4"

class API:
    """
        /api/msg?content="mystring" - send a msg to qgis using pushInfo
        /api/extent - get current extent
        /api/extent?bbox=minX,minY,maxX,maxY
        /api/features - get selected features as a csv
    """
    def __init__(self, iface):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()

    def msg(self, params, files):
        self.iface.messageBar().pushInfo("Qweb msg", params["content"])
        return "Message pushed"

    def extent(self, params, files):
        bbox = params.get("bbox", None)
        if bbox:
            extent = QgsRectangle(*[float(i) for i in bbox.split(",")])
            self.canvas.setExtent(extent)
        return {"bbox": ",".join([str(i) for i in self.canvas.extent().toRectF().getCoords()])}

    def set_extent(self, params, files):
        """Set the extent of the qgis map.

        set_extent(**{'xmin': 0, 'ymin': 0, 'xmax': 1', 'ymax': 1})

        """
        print("Qweb.set_extent: received params of type {}".format(type(params)))
        print("Qweb.set_extent: received params {}".format(params))
        keys = ['xmin', 'ymin', 'xmax', 'ymax']
        xform = dict.fromkeys(keys, float)
        kwargs = unpack_kwargs(keys, params, xform)
        print("QWeb.set_extent: Made kwargs {}".format(kwargs))
        self.canvas.setExtent(QgsRectangle(**kwargs))

    def add_raster_layer(self, params, files):
        """Add a WMS layer to the project.

        add_raster_layer(uri, baseName, providerKey)
          where
            uri: <str> query params string with url, crs, format, layers, styles keys
                 e.g. 'crs=EPSG:4326&dpiMode=7&format=image/png&layers=coastline&styles=&url=http://geoserver.dpaw.wa.gov.au/geoserver/public/wms?'
            baseName: <str> The name to call the layer in the QGS layers
                 e.g. 'WA Coastline'
            providerKey: <str> The type of service
                 e.g. 'wms'

        But beware because the params object is a bottle formsdict which returns strings.
        So perhaps inject a json string?

        Like ?args={"uri": "http://..", "baseName": .., "providerKey"}

        So what do we like:

        api/set_extent?uri=http://&baseName=...&providerKey=wms

        or

        api/set_extent?kwargs={"uri":'http://..', "baseName":}
        """
        keys = ['uri', 'baseName', 'providerKey']
        args = unpack_args(keys, params)
        print("QWeb.add_raster_layer: made args {}".format(args))
        self.iface.addRasterLayer(*args)

    def add_vector_layer(self, params, files):
        """
        Add a geojson layer to the map.

        params = {
          'data_source': '',
          'layer_name': 'feature',
          'provider_name': 'ogr',
          'data': '{feature...}'

        }
        layer = QgsVectorLayer(data_source, layer_name, provider_name)
        if not layer.isValid():
            print "Layer failed to load!"
        """
        import json, tempfile
        data_source   = params.get('data_source', '')
        layer_name    = params.get('layer_name', 'feature')
        provider_name = params.get('provider_name', 'ogr')
        # Placeholder
        gtext = json.dumps({
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [[
                    [113.3, -26.5],
                    [114.3, -26.5],
                    [114.3, -25.5],
                    [113.3, -25.5],
                    [113.3, -26.5]
                ]]
            }} )
        data = params.get('data', gtext)
        # Do we need a temp file?
        if len(data) and data_source == '':
            sink = tempfile.NamedTemporaryFile(delete=False)
            sink.write(data)
            filepath = sink.name
            sink.close()
        else:
            filepath = data_source

        # filepath = '/tmp/feature.json'
        self.iface.addVectorLayer(filepath, layer_name,  provider_name)

    def features(self, params, files):
        csvdata = []
        csvdata.append(["geom"] + [f.name() for f in self.iface.activeLayer().getFeatures().next().fields()])
        for f in self.iface.activeLayer().selectedFeatures():
            csvdata.append([f.geometry().exportToWkt()] + f.attributes())
        si = StringIO()
        csv.writer(si).writerows(csvdata)
        return {"csv": si.getvalue()}

    def add(self, params, files):
        return params["a"] + params["b"]

    ###########################################3
    ### Outgoing commands

    def fetch(self, params, files):
        """ Harvest map details from QGIS.

        This is a reminder (to me) that the code here should be app-focused.
        That is a faithful representation of the QGIS objects.
        The transform to an urmap shold really occur in the monorail plugin.

        The reasons for this are:
        1. Reduce code surface in slow-changing client environment
        2. Reduce code complexity in difficult test environment
        3. Make context one-to-one
        """
        canvas = self.iface.mapCanvas()
        size = canvas.size()
        extent = get_extent(self.iface)
        layers = self.iface.legendInterface().layers()
        tile_layers    = dict(map(xform_raster, filter(is_raster, layers)))
        feature_layers = dict(map(xform_vector, filter(is_vector, layers)))
        feature_data   = dict(map(geojson_data, filter(is_vector, layers)))
        layer_ids = [layer.id() for layer in layers]
        urmap = {                  # This will be serialized by bottle before sending I think.
            'base': {
                'bounds': extent,
                'projection': canvas.mapRenderer().destinationCrs().authid(),
            },
            'layout': {
                'container': {
                    'width': size.width(),     # px
                    'height': size.height(),   # px
                    'orientation': None,
                },
                'layers': layer_ids,     # Ordered list of layer ids
                'widgets': [],    # Ordered list of widget ids
            },
            'widgets': {},        # Legends, compass roses and scale bars
            # 'tileLayers': tile_layers, # Errors
            'tileLayers': {
                'coastline': {
                    'data_source': 'crs=EPSG:4326&dpiMode=7&format=image/png&layers=coastline&styles=&url=http://geoserver.dpaw.wa.gov.au/geoserver/public/wms?',
                    'layer_name': 'WA Coastline',
                    'provider_name': 'wms',
                    'id': 'coastline',
                },
                'dec_tenure': {
                    'id': 'dec_tenure',
                    'data_source': 'crs=EPSG:4326&dpiMode=7&format=image/png&layers=dec_tenure&styles=&url=http://geoserver.dpaw.wa.gov.au/geoserver/public/wms?',
                    'layer_name': 'DEC Tenure',
                    'provider_name': 'wms',
                },
            },
            'featureLayers': feature_layers, # All good
            # 'featureLayers': {
            #     'feature_abc': {
            #         'id': 'feature_abx',
            #         'data_source': '/tmp/tmpN8_drQ',
            #         'layer_name': 'feature',
            #         'provider': 'ogr',
            #     },
            #     'feature_def': {
            #         'id': 'feature_def',
            #         'data_source': '$ref',
            #         '$ref': ['root', 'data', 'feature_def'],
            #         'layer_name': 'other_feature',
            #         'provider_name': 'ogr',
            #     }
            # },
            'data': feature_data,            # Embedded geojson data
            # 'data': {             # Embedded geojson data
            #     'feature_def': {
            #         "geometry": {
            #             "type": "Polygon",
            #             "coordinates": [
            #                 [
            #                     [113.3, -26.5],
            #                     [114.3, -26.5],
            #                     [114.3, -25.5],
            #                     [113.3, -25.5],
            #                     [113.3, -26.5]
            #                 ]
            #             ]
            #         },
            #         "type": "Feature"},
            # },
        }
        return urmap
        # return {"features": None}




### Utility functions

def get_extent(iface):
    """Get the extent of the qgis map.
    /api/extent?bbox=minX,minY,maxX,maxY
    set_extent(**{'xmin': 0, 'ymin': 0, 'xmax': 1', 'ymax': 1})

    """
    keys = ['xmin', 'ymin', 'xmax', 'ymax']
    vals =  iface.mapCanvas().extent().toRectF().getCoords()
    extent = dict(zip(keys, vals))
    return extent

def key_dict(key, xs):
    return {x[key]: x for x in xs}

def is_raster(layer):
    return isinstance(layer, QgsRasterLayer)

def is_vector(layer):
    return isinstance(layer, QgsVectorLayer)

def unpack_kwargs(keys, params, xform=None):
    """Pluck and transform keys, return dict"""
    if xform is None:
        xform = dict.fromkeys(keys, identity)
    kwargs = {k: xform[k](params[k]) for k in keys}
    return kwargs

def xform_dict(params, xform):
    kwargs = {k: xfrom[k](v) for k, v in params.iteritems()}
    return kwargs

def xform_raster(layer, direction='netwards'):
    """Transform the layer between app and net representations."""
    if direction == 'netwards':
        xlayer = netwards_raster(layer)
    elif direction == 'appwards':
        xlayer = appwards_raster(layer)
    else:
        msg = "The xform direction must be appwards | netwards, not {}".format(direction)
        raise TypeError(msg)
    return xlayer

def appwards_raster(layer):
    raise NotImplementedError

def netwards_raster(layer):
    """
    Example from QGSRasterLayer Object ->  
    {
        'data_source': 'crs=EPSG:4326&dpiMode=7&format=image/png&layers=coastline&styles=&url=http://geoserver.dpaw.wa.gov.au/geoserver/public/wms?',
        'layer_name': 'WA Coastline',
        'provider_name': 'wms',
        'id': 'coastline',
    },
    """
    provider = layer.dataProvider()
    _id = layer.id()
    tile = {
        "data_source": layer.dataProvider().dataSourceUri(),
        "layer_name": layer.name(),
        "provider_name": layer.providerType(),
        "id": id
    }
    return (_id, tile)

def xform_vector(layer, direction='netwards'):
    """Transform the layer between app and net representations."""
    if direction == 'netwards':
        xlayer = netwards_vector(layer)
    elif direction == 'appwards':
        xlayer = appwards_vector(layer)
    else:
        msg = "The xform direction must be appwards | netwards, not {}".format(direction)
        raise TypeError(msg)
    return xlayer

def appwards_vector(layer):
    raise NotImplementedError

def netwards_vector(layer):
    """
    QgsVectorLayer -> {
        'id': 'feature_def',
        'data_source': '$ref',
        '$ref': ['root', 'data', 'feature_def'],
        'layer_name': 'other_feature',
        'provider_name': 'ogr',
    }
    plus embedded data;
    """
    _id = layer.id()
    feat_coll = {
        "id": _id,
        "data_source": "$ref",
        "$ref": ["root", "data", _id],
        "layer_name": layer.name(),
        "provider_name": layer.providerType()
    }
    return (_id, feat_coll)

def geojson_data(layer):
    """Return the geojson data as a dict"""
    _id = layer.id()
    fp = layer.source()
    if not osp.isfile(fp):
        msg = "Check {} is an existing file".format(fp)
        raise IOError(msg)
    with open(fp) as src:
        data = json.load(src)
    return (_id, data)

def unpack_args(keys, params, xform=None):
    """Plucks and transform keys from params dict"""
    if xform is None:
        args = [params[k] for k in keys]
    else:
        args = [xform[k](params[k]) for k in keys]
    return args

def identity(v):
    return v
