print "Importing packages.__init__"

__version__ = "0.2.6"

import bootstrap
import api
import mybottle
