print "Importing packages.__init__"

__version__ = "0.2.5"

import bootstrap
import api
import mybottle
