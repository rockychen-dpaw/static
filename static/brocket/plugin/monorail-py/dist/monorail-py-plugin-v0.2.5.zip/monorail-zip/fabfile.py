
import os, sys
import os.path as osp
from fabric.api import *


@task
def zip():
    cmd = "zip -r monorail-packages.zip packages"
    with settings(warn_only=True):
        local(cmd)

@task
def deploy():
    cmd = "scp monorail-packages.zip oim1:/var/www/static-pages.8022/static/brocket/plugin/monorail-py/dist/"
    with settings(warn_only=True):
        local(cmd)
