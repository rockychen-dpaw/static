print "Importing packages.__init__"

__version__ = "0.0.1"

import bootstrap
import api
import mybottle
