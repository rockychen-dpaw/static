QGIS Monorail Plugin
====================

This plugin is designed to work inside of your local QGIS installation.
It's written in Python and Qt and will work hand-in-hand with the Javascript Monorail plugin to communicate with other applications over the brocket (*Br*oadcast S*ocket*) network.

## Getting started
You can install the plugin from a zip package or build from the source repo.
In time, it will be distributed with directly inside QGIS with your usual updates.

### Get the zip

There is an Ubuntu zip available on the
[bitbucket downloads](https://bitbucket.org/dpaw/monorail/downloads) page for the repo.

Do this:

- Download and unzip the package in your QGIS plugin directory.
  For me this is ``~/.qgis2/python/plugins`.
  You will now have a monorail directory inside the plugins directory`
- Install the plugin from inside QGIS.
In the title bar click: Plugins -> Manage and Update Plugins ...
Wait for the Plugins windows to connect to the QGIS Server and search "monorail".
If it's not visible, you may have to restart QGIS so it sees the new files.
Ensure the checkbox is checked
- Click the new plugin button on your toolbar, (Looks like a green plug on a yellow background)
This will open a webpage that will be your gateway to the heady heady heights of inter-app communication.


### Build the source

Until we have binaries for windows hosted, you will need to build the PyQt source.

    cd ~/.qgis2/python/plugins/monorail
    pyrcc4 -o resources.py resources.qrc

should do it, but I'm unsure of the Windows dependencies for this...

