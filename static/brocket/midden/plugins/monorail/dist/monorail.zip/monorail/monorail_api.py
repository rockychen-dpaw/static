from qgis.core import *
from StringIO import StringIO
import csv

class API:
    """
        /api/msg?content="mystring" - send a msg to qgis using pushInfo
        /api/extent - get current extent
        /api/extent?bbox=minX,minY,maxX,maxY
        /api/features - get selected features as a csv
    """
    def __init__(self, iface):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()

    def msg(self, params, files):
        self.iface.messageBar().pushInfo("Qweb msg", params["content"])
        return "Message pushed"

    def extent(self, params, files):
        bbox = params.get("bbox", None)
        if bbox:
            extent = QgsRectangle(*[float(i) for i in bbox.split(",")])
            self.canvas.setExtent(extent)
        return {"bbox": ",".join([str(i) for i in self.canvas.extent().toRectF().getCoords()])}

    def set_extent(self, params, files):
        """Set the extent of the qgis map.

        set_extent(**{'xmin': 0, 'ymin': 0, 'xmax': 1', 'ymax': 1})

        """
        print("Qweb.set_extent: received params of type {}".format(type(params)))
        print("Qweb.set_extent: received params {}".format(params))
        keys = ['xmin', 'ymin', 'xmax', 'ymax']
        xform = dict.fromkeys(keys, float)
        kwargs = unpack_kwargs(keys, params, xform)
        print("QWeb.set_extent: Made kwargs {}".format(kwargs))
        self.canvas.setExtent(QgsRectangle(**kwargs))

    def add_raster_layer(self, params, files):
        """Add a WMS layer to the project.

        add_raster_layer(uri, baseName, providerKey)
          where
            uri: <str> query params string with url, crs, format, layers, styles keys
                 e.g. 'crs=EPSG:4326&dpiMode=7&format=image/png&layers=coastline&styles=&url=http://geoserver.dpaw.wa.gov.au/geoserver/public/wms?'
            baseName: <str> The name to call the layer in the QGS layers
                 e.g. 'WA Coastline'
            providerKey: <str> The type of service
                 e.g. 'wms'

        But beware because the params object is a bottle formsdict which returns strings.
        So perhaps inject a json string?

        Like ?args={"uri": "http://..", "baseName": .., "providerKey"}

        So what do we like:

        api/set_extent?uri=http://&baseName=...&providerKey=wms

        or

        api/set_extent?kwargs={"uri":'http://..', "baseName":}
        """
        keys = ['uri', 'baseName', 'providerKey']
        args = unpack_args(keys, params)
        print("QWeb.add_raster_layer: made args {}".format(args))
        self.iface.addRasterLayer(*args)

    def add_vector_layer(self, params, files):
        """
        Add a geojson layer to the map.

        params = {
          'data_source': '',
          'layer_name': 'feature',
          'provider_name': 'ogr',
          'data': '{feature...}'

        }
        layer = QgsVectorLayer(data_source, layer_name, provider_name)
        if not layer.isValid():
            print "Layer failed to load!"
        """
        import json, tempfile
        data_source   = params.get('data_source', '')
        layer_name    = params.get('layer_name', 'feature')
        provider_name = params.get('provider_name', 'ogr')
        # Placeholder
        gtext = json.dumps({
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [[
                    [113.3, -26.5],
                    [114.3, -26.5],
                    [114.3, -25.5],
                    [113.3, -25.5],
                    [113.3, -26.5]
                ]]
            }} )
        data = params.get('data', gtext)
        # Do we need a temp file?
        if len(data) and data_source == '':
            sink = tempfile.NamedTemporaryFile(delete=False)
            sink.write(data)
            filepath = sink.name
            sink.close()
        else:
            filepath = data_source

        # filepath = '/tmp/feature.json'
        self.iface.addVectorLayer(filepath, layer_name,  provider_name)

    def features(self, params, files):
        csvdata = []
        csvdata.append(["geom"] + [f.name() for f in self.iface.activeLayer().getFeatures().next().fields()])
        for f in self.iface.activeLayer().selectedFeatures():
            csvdata.append([f.geometry().exportToWkt()] + f.attributes())
        si = StringIO()
        csv.writer(si).writerows(csvdata)
        return {"csv": si.getvalue()}

    def add(self, params, files):
        return params["a"] + params["b"]

    ###########################################3
    ### Outgoing commands

    def fetch(self, params, files):
        """ Harvest map details from QGIS.
        """
        extent = get_extent(self.iface)
        urmap = {                  # This will be serialized by bottle before sending I think.
            'base': {
                'bounds': extent,
                'projection': '',
            },
            'tileLayers': {
                'coastline': {
                    'data_source': 'crs=EPSG:4326&dpiMode=7&format=image/png&layers=coastline&styles=&url=http://geoserver.dpaw.wa.gov.au/geoserver/public/wms?',
                    'layer_name': 'WA Coastline',
                    'provider_name': 'wms',
                    'id': 'coastline',
                },
                'dec_tenure': {
                    'id': 'dec_tenure',
                    'data_source': 'crs=EPSG:4326&dpiMode=7&format=image/png&layers=dec_tenure&styles=&url=http://geoserver.dpaw.wa.gov.au/geoserver/public/wms?',
                    'layer_name': 'DEC Tenure',
                    'provider_name': 'wms',
                },
            },
            'featureLayers': {
                'feature_abc': {
                    'id': 'feature_abx',
                    'data_source': '/tmp/tmpN8_drQ',
                    'layer_name': 'feature',
                    'provider': 'ogr',
                },
                'feature_def': {
                    'id': 'feature_def',
                    'data_source': '$ref',
                    '$ref': ['root', 'data', 'feature_def'],
                    'layer_name': 'other_feature',
                    'provider_name': 'ogr',
                }
            },
            'layout': {
                'container': {
                    'width': None,
                    'height': None,
                    'orientation': None,
                },
                'layers': [],     # Ordered list of layer ids
                'widgets': [],    # Ordered list of widget ids
            },
            'widgets': {},        # Legends, compass roses and scale bars
            'data': {             # Embedded geojson data
                'feature_def': {
                    "geometry": {
                        "type": "Polygon",
                        "coordinates": [
                            [
                                [113.3, -26.5],
                                [114.3, -26.5],
                                [114.3, -25.5],
                                [113.3, -25.5],
                                [113.3, -26.5]
                            ]
                        ]
                    },
                    "type": "Feature"},
            },
        }
        return urmap




### Utility functions

def get_extent(iface):
    """Get the extent of the qgis map.
    /api/extent?bbox=minX,minY,maxX,maxY
    set_extent(**{'xmin': 0, 'ymin': 0, 'xmax': 1', 'ymax': 1})

    """
    keys = ['xmin', 'ymin', 'xmax', 'ymax']
    vals =  iface.mapCanvas().extent().toRectF().getCoords()
    extent = dict(zip(keys, vals))
    return extent

def unpack_kwargs(keys, params, xform=None):
    """Pluck and transform keys, return dict"""
    if xform is None:
        xform = dict.fromkeys(keys, identity)
    kwargs = {k: xform[k](params[k]) for k in keys}
    return kwargs

def xform_dict(params, xform):
    kwargs = {k: xfrom[k](v) for k, v in params.iteritems()}
    return kwargs

def unpack_args(keys, params, xform=None):
    """Plucks and transform keys from params dict"""
    if xform is None:
        args = [params[k] for k in keys]
    else:
        args = [xform[k](params[k]) for k in keys]
    return args

def identity(v):
    return v
