import requests, json
from django import http
from django.conf import settings
from django.contrib.auth import login
from django.contrib.auth.models import User


class SSOLoginMiddleware(object):
    def process_request(self, request):
        if not request.user.is_authenticated():
            try:
                userdata = json.loads(requests.get(settings.SSO_URL + "/api/whoami", cookies=request.COOKIES).content)
            except:
                return http.HttpResponseRedirect(settings.SSO_URL + "/redirect/" + request.get_host() + request.get_full_path())
            del userdata["shared_id"]
            if User.objects.filter(email__istartswith=userdata["email"]).exists():
                user = User.objects.get(email__istartswith=userdata["email"])
            else:
                user = User()
            user.email = userdata["email"]
            user.username = userdata["username"]
            user.first_name = userdata["first_name"]
            user.last_name = userdata["last_name"]
            user.save()
            user.backend = settings.AUTHENTICATION_BACKENDS[0]
            login(request, user)

