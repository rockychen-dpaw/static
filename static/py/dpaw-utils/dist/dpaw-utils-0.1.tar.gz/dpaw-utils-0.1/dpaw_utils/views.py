from django import http
from django.conf import settings
from django.contrib.auth import logout


def logout_view(request):
    logout(request)
    return http.HttpResponseRedirect(settings.SSO_URL + "/logout")
