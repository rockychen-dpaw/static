from django import http
from django.contrib.auth import login, logout
from django.contrib.auth.models import User


class SSOLoginMiddleware(object):
    def process_request(self, request):
        if not request.user.is_authenticated() and "HTTP_REMOTE_USER" in request.META:
            attributemap = {
                "username": "HTTP_REMOTE_USER",
                "last_name": "HTTP_X_LAST_NAME",
                "first_name": "HTTP_X_FIRST_NAME",
                "email": "HTTP_X_EMAIL",
            }
            for key, value in attributemap.iteritems():
                attributemap[key] = request.META[value]
            if User.objects.filter(email__istartswith=attributemap["email"]).exists():
                user = User.objects.get(email__istartswith=attributemap["email"])
            else:
                user = User()
            user.__dict__.update(attributemap)
            user.save()
            user.backend = self.__class__.__name__
            login(request, user)
        elif request.user.is_authenticated() and request.path.startswith('/logout'):
            if request.session.get("BACKEND_SESSION_KEY") == self.__class__.__name__:
                logout(request, user)
                return http.HttpResponseRedirect(request.META["HTTP_X_LOGOUT_URL"])

